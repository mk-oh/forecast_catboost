# forecast_catboost
Time-series modeling with catboost ( R Ver. )

## Installation
Testing Pkg
```r
devtools::install_github("mk-oh/forecast_catboost")
```

